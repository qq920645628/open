Reach out to help@openinterpreter.com for support.
